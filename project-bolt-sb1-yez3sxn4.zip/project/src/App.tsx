import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Navigation from './components/Navigation';
import Dashboard from './pages/Dashboard';
import ReportIssue from './pages/ReportIssue';
import HelpGuide from './pages/HelpGuide';
import AIChat from './pages/AIChat';
import ImageRecognition from './pages/ImageRecognition';
import Footer from './components/Footer';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Navigation />
        <main className="flex-1">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/report" element={<ReportIssue />} />
            <Route path="/help" element={<HelpGuide />} />
            <Route path="/ai-chat" element={<AIChat />} />
            <Route path="/image-recognition" element={<ImageRecognition />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;