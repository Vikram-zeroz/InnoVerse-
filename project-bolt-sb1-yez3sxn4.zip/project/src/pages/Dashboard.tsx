import React from 'react';
import { Link } from 'react-router-dom';
import { FileText, Bot, Camera, HelpCircle, AlertTriangle, CheckCircle, Clock, Users } from 'lucide-react';

const Dashboard: React.FC = () => {
  const stats = [
    { label: 'Total Issues Reported', value: '1,247', icon: AlertTriangle, color: 'text-orange-600 bg-orange-100' },
    { label: 'Issues Resolved', value: '892', icon: CheckCircle, color: 'text-green-600 bg-green-100' },
    { label: 'Pending Issues', value: '355', icon: Clock, color: 'text-yellow-600 bg-yellow-100' },
    { label: 'Active Users', value: '3,428', icon: Users, color: 'text-blue-600 bg-blue-100' },
  ];

  const quickActions = [
    {
      title: 'Report New Issue',
      description: 'Submit a new civic issue with photos and detailed description',
      icon: FileText,
      path: '/report',
      color: 'bg-blue-600 hover:bg-blue-700',
    },
    {
      title: 'AI Assistant',
      description: 'Get help from our AI chatbot for guidance and support',
      icon: Bot,
      path: '/ai-chat',
      color: 'bg-purple-600 hover:bg-purple-700',
    },
    {
      title: 'Image Recognition',
      description: 'Use AI to automatically categorize issues from images',
      icon: Camera,
      path: '/image-recognition',
      color: 'bg-green-600 hover:bg-green-700',
    },
    {
      title: 'Help Guide',
      description: 'Learn how to effectively report and track civic issues',
      icon: HelpCircle,
      path: '/help',
      color: 'bg-indigo-600 hover:bg-indigo-700',
    },
  ];

  const recentIssues = [
    { id: 1, title: 'Broken Street Light', location: 'Main Street, Block A', status: 'In Progress', time: '2 hours ago' },
    { id: 2, title: 'Pothole on Highway', location: 'Highway 45, Mile 12', status: 'Reported', time: '5 hours ago' },
    { id: 3, title: 'Garbage Collection Missed', location: 'Residential Area B', status: 'Resolved', time: '1 day ago' },
    { id: 4, title: 'Water Leakage', location: 'Park Avenue', status: 'In Progress', time: '2 days ago' },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Resolved': return 'text-green-700 bg-green-100';
      case 'In Progress': return 'text-yellow-700 bg-yellow-100';
      case 'Reported': return 'text-blue-700 bg-blue-100';
      default: return 'text-gray-700 bg-gray-100';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Hero Section */}
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
          Welcome to CivicSolver
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
          Your one-stop platform for reporting and tracking civic issues. Together, we can make our community better.
        </p>
        <Link
          to="/report"
          className="inline-flex items-center px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors duration-200 shadow-lg hover:shadow-xl"
        >
          <FileText className="h-5 w-5 mr-2" />
          Report an Issue
        </Link>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow duration-200">
              <div className="flex items-center">
                <div className={`p-3 rounded-full ${stat.color}`}>
                  <Icon className="h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick Actions */}
      <div className="mb-12">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <Link
                key={index}
                to={action.path}
                className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-all duration-200 transform hover:-translate-y-1 group"
              >
                <div className={`w-12 h-12 ${action.color} rounded-lg flex items-center justify-center mb-4 transition-colors duration-200`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2 group-hover:text-gray-700">
                  {action.title}
                </h3>
                <p className="text-sm text-gray-600">{action.description}</p>
              </Link>
            );
          })}
        </div>
      </div>

      {/* Recent Issues */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Recent Issues</h2>
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Issue
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Location
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Time
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {recentIssues.map((issue) => (
                  <tr key={issue.id} className="hover:bg-gray-50 transition-colors duration-150">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{issue.title}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-600">{issue.location}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(issue.status)}`}>
                        {issue.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                      {issue.time}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;