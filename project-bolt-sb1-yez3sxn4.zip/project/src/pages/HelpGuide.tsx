import React, { useState } from 'react';
import { ChevronDown, ChevronRight, FileText, Camera, Mail, Clock, CheckCircle, AlertCircle } from 'lucide-react';

const HelpGuide: React.FC = () => {
  const [expandedSections, setExpandedSections] = useState<number[]>([0]);

  const toggleSection = (index: number) => {
    setExpandedSections(prev => 
      prev.includes(index) 
        ? prev.filter(i => i !== index)
        : [...prev, index]
    );
  };

  const helpSections = [
    {
      title: 'Getting Started',
      icon: FileText,
      content: (
        <div className="space-y-4">
          <p className="text-gray-700">
            Welcome to CivicSolver! This platform helps you report and track civic issues in your community. 
            Here's how to get started:
          </p>
          <ol className="list-decimal list-inside space-y-2 text-gray-700 ml-4">
            <li>Navigate to the "Report Issue" page from the main menu</li>
            <li>Fill out the issue reporting form with accurate details</li>
            <li>Upload photos if available to help illustrate the problem</li>
            <li>Provide your contact information for follow-ups</li>
            <li>Submit the form and receive a confirmation email</li>
          </ol>
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-4">
            <p className="text-blue-800 font-medium">
              💡 Tip: The more detailed your report, the faster authorities can address the issue!
            </p>
          </div>
        </div>
      )
    },
    {
      title: 'How to Report Issues Effectively',
      icon: AlertCircle,
      content: (
        <div className="space-y-4">
          <p className="text-gray-700 mb-4">Follow these best practices for effective issue reporting:</p>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <h4 className="font-semibold text-green-800 mb-2">✅ Do This</h4>
              <ul className="space-y-1 text-green-700 text-sm">
                <li>• Be specific about the location</li>
                <li>• Include clear, well-lit photos</li>
                <li>• Describe the safety impact</li>
                <li>• Mention how long the issue exists</li>
                <li>• Use the correct category</li>
              </ul>
            </div>
            
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <h4 className="font-semibold text-red-800 mb-2">❌ Avoid This</h4>
              <ul className="space-y-1 text-red-700 text-sm">
                <li>• Vague descriptions like "broken thing"</li>
                <li>• Blurry or dark photos</li>
                <li>• Reporting the same issue multiple times</li>
                <li>• Using inappropriate language</li>
                <li>• Missing contact information</li>
              </ul>
            </div>
          </div>

          <div className="mt-6">
            <h4 className="font-semibold text-gray-800 mb-3">Priority Levels Guide:</h4>
            <div className="space-y-2">
              <div className="flex items-center p-2 bg-red-50 rounded-lg">
                <div className="w-3 h-3 bg-red-500 rounded-full mr-3"></div>
                <span className="text-sm"><strong>High:</strong> Safety hazards, blocked roads, water/gas leaks</span>
              </div>
              <div className="flex items-center p-2 bg-yellow-50 rounded-lg">
                <div className="w-3 h-3 bg-yellow-500 rounded-full mr-3"></div>
                <span className="text-sm"><strong>Medium:</strong> Potholes, streetlight issues, noise complaints</span>
              </div>
              <div className="flex items-center p-2 bg-green-50 rounded-lg">
                <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                <span className="text-sm"><strong>Low:</strong> Cosmetic issues, general maintenance requests</span>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      title: 'Photo Guidelines',
      icon: Camera,
      content: (
        <div className="space-y-4">
          <p className="text-gray-700 mb-4">
            Good photos are crucial for quick issue resolution. Follow these guidelines:
          </p>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-gray-800 mb-3">Photo Requirements:</h4>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                  <span>Clear, well-lit images</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                  <span>Multiple angles if possible</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                  <span>Include context (street signs, landmarks)</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                  <span>Maximum 5 images per report</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                  <span>Formats: JPG, PNG (up to 10MB each)</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-semibold text-gray-800 mb-3">Photo Tips:</h4>
              <ul className="space-y-1 text-gray-600 text-sm">
                <li>• Take photos during daylight when possible</li>
                <li>• Show the full extent of the problem</li>
                <li>• Include before/after if the issue changed</li>
                <li>• Capture any relevant signage or markers</li>
                <li>• Avoid including people's faces for privacy</li>
              </ul>
            </div>
          </div>
        </div>
      )
    },
    {
      title: 'Email Notification Process',
      icon: Mail,
      content: (
        <div className="space-y-4">
          <p className="text-gray-700 mb-4">
            Understanding how email notifications work in the issue reporting process:
          </p>
          
          <div className="space-y-4">
            <div className="flex items-start p-4 bg-blue-50 rounded-lg">
              <div className="bg-blue-500 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold mr-4 mt-1">1</div>
              <div>
                <h4 className="font-semibold text-blue-800">Immediate Confirmation</h4>
                <p className="text-blue-700 text-sm mt-1">
                  You receive a confirmation email immediately after submitting your report with a tracking number.
                </p>
              </div>
            </div>
            
            <div className="flex items-start p-4 bg-yellow-50 rounded-lg">
              <div className="bg-yellow-500 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold mr-4 mt-1">2</div>
              <div>
                <h4 className="font-semibold text-yellow-800">Authority Notification</h4>
                <p className="text-yellow-700 text-sm mt-1">
                  Relevant authorities receive an automated email with your issue details and photos for immediate action.
                </p>
              </div>
            </div>
            
            <div className="flex items-start p-4 bg-green-50 rounded-lg">
              <div className="bg-green-500 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold mr-4 mt-1">3</div>
              <div>
                <h4 className="font-semibold text-green-800">Status Updates</h4>
                <p className="text-green-700 text-sm mt-1">
                  You'll receive email updates when your issue status changes (In Progress, Resolved, etc.).
                </p>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 mt-6">
            <h4 className="font-semibold text-gray-800 mb-2">Email Categories by Issue Type:</h4>
            <div className="grid md:grid-cols-2 gap-4 text-sm">
              <div>
                <p><strong>Infrastructure:</strong> Public Works Department</p>
                <p><strong>Safety:</strong> Police & Emergency Services</p>
                <p><strong>Environment:</strong> Environmental Health Dept.</p>
                <p><strong>Transportation:</strong> Traffic Management</p>
              </div>
              <div>
                <p><strong>Utilities:</strong> Utility Companies</p>
                <p><strong>Parks:</strong> Parks & Recreation Dept.</p>
                <p><strong>Housing:</strong> Building Code Enforcement</p>
                <p><strong>Other:</strong> General Administration</p>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      title: 'Response Times & Follow-up',
      icon: Clock,
      content: (
        <div className="space-y-4">
          <p className="text-gray-700 mb-4">
            Expected response times vary based on issue priority and type:
          </p>
          
          <div className="space-y-4">
            <div className="bg-red-50 border-l-4 border-red-500 p-4">
              <h4 className="font-semibold text-red-800">🚨 Emergency Issues</h4>
              <p className="text-red-700 text-sm mt-1">
                <strong>Response:</strong> Immediate (within 2 hours)<br/>
                <strong>Examples:</strong> Gas leaks, blocked emergency routes, dangerous conditions
              </p>
            </div>
            
            <div className="bg-yellow-50 border-l-4 border-yellow-500 p-4">
              <h4 className="font-semibold text-yellow-800">⚠️ High Priority</h4>
              <p className="text-yellow-700 text-sm mt-1">
                <strong>Response:</strong> 24-48 hours<br/>
                <strong>Examples:</strong> Traffic light malfunctions, major potholes, water main issues
              </p>
            </div>
            
            <div className="bg-blue-50 border-l-4 border-blue-500 p-4">
              <h4 className="font-semibold text-blue-800">📋 Standard Issues</h4>
              <p className="text-blue-700 text-sm mt-1">
                <strong>Response:</strong> 3-7 business days<br/>
                <strong>Examples:</strong> Street cleaning, minor repairs, routine maintenance
              </p>
            </div>
          </div>

          <div className="bg-gray-100 rounded-lg p-4 mt-6">
            <h4 className="font-semibold text-gray-800 mb-2">What to Expect:</h4>
            <ul className="space-y-1 text-gray-700 text-sm">
              <li>• Initial acknowledgment email within 2 hours</li>
              <li>• Assignment to appropriate department</li>
              <li>• Investigation and assessment</li>
              <li>• Regular status updates via email</li>
              <li>• Completion notification with resolution details</li>
            </ul>
          </div>
        </div>
      )
    }
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Help Guide</h1>
        <p className="text-lg text-gray-600">
          Learn how to effectively report civic issues and track their progress
        </p>
      </div>

      <div className="space-y-4">
        {helpSections.map((section, index) => {
          const Icon = section.icon;
          const isExpanded = expandedSections.includes(index);
          
          return (
            <div key={index} className="bg-white rounded-lg shadow-md border border-gray-200">
              <button
                onClick={() => toggleSection(index)}
                className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-50 transition-colors duration-200"
              >
                <div className="flex items-center">
                  <Icon className="h-6 w-6 text-blue-600 mr-3" />
                  <h3 className="text-lg font-semibold text-gray-900">
                    {section.title}
                  </h3>
                </div>
                {isExpanded ? (
                  <ChevronDown className="h-5 w-5 text-gray-500" />
                ) : (
                  <ChevronRight className="h-5 w-5 text-gray-500" />
                )}
              </button>
              
              {isExpanded && (
                <div className="px-6 pb-6 border-t border-gray-100">
                  <div className="mt-4">
                    {section.content}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Quick Tips Section */}
      <div className="mt-12 bg-gradient-to-r from-blue-600 to-blue-700 rounded-lg p-8 text-white">
        <h2 className="text-2xl font-bold mb-4">Quick Tips for Success</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="text-center">
            <FileText className="h-8 w-8 mx-auto mb-2 opacity-80" />
            <h3 className="font-semibold mb-1">Be Detailed</h3>
            <p className="text-sm opacity-90">Provide specific location and clear description</p>
          </div>
          <div className="text-center">
            <Camera className="h-8 w-8 mx-auto mb-2 opacity-80" />
            <h3 className="font-semibold mb-1">Add Photos</h3>
            <p className="text-sm opacity-90">Visual evidence speeds up resolution</p>
          </div>
          <div className="text-center">
            <Clock className="h-8 w-8 mx-auto mb-2 opacity-80" />
            <h3 className="font-semibold mb-1">Be Patient</h3>
            <p className="text-sm opacity-90">Allow appropriate time for response</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HelpGuide;