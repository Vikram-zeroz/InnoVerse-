import React, { useState } from 'react';
import { Camera, Upload, Zap, CheckCircle, AlertTriangle, Info } from 'lucide-react';

const ImageRecognition: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<any>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedImage(e.target.files[0]);
      setAnalysis(null);
    }
  };

  const analyzeImage = async () => {
    if (!selectedImage) return;

    setIsAnalyzing(true);
    
    // Simulate AI analysis
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Mock analysis results
    const mockAnalysis = {
      category: 'Infrastructure',
      confidence: 87,
      description: 'Pothole detected in asphalt road surface',
      severity: 'Medium',
      suggestedPriority: 'Medium',
      location: 'Street/Road',
      additionalInfo: [
        'Approximately 2 feet in diameter',
        'Appears to be on a main road',
        'Could pose safety risk to vehicles',
        'Recommended for repair within 48-72 hours'
      ]
    };
    
    setAnalysis(mockAnalysis);
    setIsAnalyzing(false);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity.toLowerCase()) {
      case 'high': return 'text-red-600 bg-red-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'low': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">AI Image Recognition</h1>
        <p className="text-lg text-gray-600">
          Upload an image and let our AI automatically categorize and analyze civic issues
        </p>
        
        {/* Demo Notice */}
        <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4 max-w-2xl mx-auto">
          <div className="flex items-start">
            <Info className="h-5 w-5 text-blue-600 mr-2 mt-0.5" />
            <div className="text-left">
              <p className="text-sm font-medium text-blue-800">Demo Mode</p>
              <p className="text-sm text-blue-700 mt-1">
                This is a mockup interface. In production, this would use actual AI image recognition 
                technology to automatically identify and categorize civic issues from uploaded photos.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Upload Section */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
            <Camera className="h-5 w-5 mr-2 text-green-600" />
            Image Upload
          </h2>

          <div className="space-y-4">
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-gray-400 transition-colors">
              <input
                type="file"
                id="imageUpload"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
              <label htmlFor="imageUpload" className="cursor-pointer">
                <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <p className="text-lg font-medium text-gray-900 mb-2">
                  Upload Image for Analysis
                </p>
                <p className="text-sm text-gray-500">
                  PNG, JPG up to 10MB
                </p>
              </label>
            </div>

            {selectedImage && (
              <div className="space-y-4">
                <div className="relative">
                  <img
                    src={URL.createObjectURL(selectedImage)}
                    alt="Selected for analysis"
                    className="w-full h-64 object-cover rounded-lg border border-gray-200"
                  />
                  <div className="absolute top-2 right-2 bg-black bg-opacity-50 text-white px-2 py-1 rounded text-sm">
                    {selectedImage.name}
                  </div>
                </div>

                <button
                  onClick={analyzeImage}
                  disabled={isAnalyzing}
                  className="w-full flex items-center justify-center px-6 py-3 bg-green-600 hover:bg-green-700 disabled:bg-green-400 text-white font-medium rounded-lg transition-colors duration-200"
                >
                  {isAnalyzing ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-top-transparent mr-2"></div>
                      Analyzing Image...
                    </>
                  ) : (
                    <>
                      <Zap className="h-5 w-5 mr-2" />
                      Analyze with AI
                    </>
                  )}
                </button>
              </div>
            )}
          </div>

          {/* Features List */}
          <div className="mt-8 border-t border-gray-200 pt-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">AI Capabilities</h3>
            <div className="space-y-3">
              <div className="flex items-center text-sm">
                <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                <span>Automatic issue categorization</span>
              </div>
              <div className="flex items-center text-sm">
                <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                <span>Severity assessment</span>
              </div>
              <div className="flex items-center text-sm">
                <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                <span>Priority recommendation</span>
              </div>
              <div className="flex items-center text-sm">
                <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                <span>Detailed description generation</span>
              </div>
            </div>
          </div>
        </div>

        {/* Analysis Results */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
            <Zap className="h-5 w-5 mr-2 text-blue-600" />
            Analysis Results
          </h2>

          {!analysis && !isAnalyzing && (
            <div className="text-center py-12 text-gray-500">
              <Camera className="h-16 w-16 mx-auto mb-4 text-gray-300" />
              <p>Upload an image to see AI analysis results</p>
            </div>
          )}

          {isAnalyzing && (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-top-transparent mx-auto mb-4"></div>
              <p className="text-gray-600">AI is analyzing your image...</p>
              <div className="mt-4 bg-gray-50 rounded-lg p-4">
                <div className="text-left text-sm text-gray-600 space-y-1">
                  <p>• Identifying objects and patterns...</p>
                  <p>• Categorizing issue type...</p>
                  <p>• Assessing severity level...</p>
                  <p>• Generating recommendations...</p>
                </div>
              </div>
            </div>
          )}

          {analysis && (
            <div className="space-y-6">
              {/* Confidence Score */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-blue-800">Confidence Level</span>
                  <span className="text-lg font-bold text-blue-900">{analysis.confidence}%</span>
                </div>
                <div className="w-full bg-blue-200 rounded-full h-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${analysis.confidence}%` }}
                  ></div>
                </div>
              </div>

              {/* Analysis Details */}
              <div className="space-y-4">
                <div className="flex justify-between items-center py-2 border-b border-gray-200">
                  <span className="font-medium text-gray-700">Category:</span>
                  <span className="text-gray-900">{analysis.category}</span>
                </div>
                
                <div className="flex justify-between items-center py-2 border-b border-gray-200">
                  <span className="font-medium text-gray-700">Severity:</span>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getSeverityColor(analysis.severity)}`}>
                    {analysis.severity}
                  </span>
                </div>
                
                <div className="flex justify-between items-center py-2 border-b border-gray-200">
                  <span className="font-medium text-gray-700">Suggested Priority:</span>
                  <span className="text-gray-900">{analysis.suggestedPriority}</span>
                </div>
                
                <div className="flex justify-between items-center py-2 border-b border-gray-200">
                  <span className="font-medium text-gray-700">Location Type:</span>
                  <span className="text-gray-900">{analysis.location}</span>
                </div>
              </div>

              {/* Description */}
              <div>
                <h4 className="font-medium text-gray-700 mb-2">AI Description:</h4>
                <p className="text-gray-900 bg-gray-50 rounded-lg p-3">{analysis.description}</p>
              </div>

              {/* Additional Info */}
              <div>
                <h4 className="font-medium text-gray-700 mb-3">Additional Insights:</h4>
                <ul className="space-y-2">
                  {analysis.additionalInfo.map((info: string, index: number) => (
                    <li key={index} className="flex items-start text-sm">
                      <AlertTriangle className="h-4 w-4 text-yellow-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">{info}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Action Button */}
              <div className="pt-4 border-t border-gray-200">
                <button className="w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors duration-200">
                  Use This Analysis in Report
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* How It Works */}
      <div className="mt-12 bg-gradient-to-r from-green-600 to-green-700 rounded-lg p-8 text-white">
        <h2 className="text-2xl font-bold mb-6 text-center">How AI Image Recognition Works</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="bg-white bg-opacity-20 p-3 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <Upload className="h-8 w-8" />
            </div>
            <h3 className="font-semibold mb-2">1. Upload Image</h3>
            <p className="text-sm opacity-90">Upload a photo of the civic issue you want to report</p>
          </div>
          <div className="text-center">
            <div className="bg-white bg-opacity-20 p-3 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <Zap className="h-8 w-8" />
            </div>
            <h3 className="font-semibold mb-2">2. AI Analysis</h3>
            <p className="text-sm opacity-90">Our AI analyzes the image and identifies the issue type</p>
          </div>
          <div className="text-center">
            <div className="bg-white bg-opacity-20 p-3 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <CheckCircle className="h-8 w-8" />
            </div>
            <h3 className="font-semibold mb-2">3. Get Results</h3>
            <p className="text-sm opacity-90">Receive categorization, priority, and detailed analysis</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImageRecognition;